# Modèle logique

```
 student (STUD_NUMBER, first_name, last_name, gender)
 emailAddress (EMAIL, stud_number)
 association (ASSO_NAME, asso_desc)
 membership (STUD_NUMBER, ASSO_NAME, stud_role)
 ascEdition (YEAR, registration_fee)
 registration (STUD_NUMBER, YEAR, registration_date, payment_date)
 login (USERNAME, password)
```


Clés étrangères
```
    emailAddress(stud_number) references student(stud_number)
    membership(stud_number) references student(stud_number)
    membership(asso_name) references association(asso_name)
    registration(stud_number) references student(stud_number),
    registration(year) references ascEdition(year) 
```
